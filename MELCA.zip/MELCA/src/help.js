const help = (prefix) => { 
	return `   *🍁MENU MELCABOT 🍁*
	
	
*╭═┅ৡৢ͜͡✦═══╡꧁꧂╞═══┅ৡৢ͜͡✦═╮*
*║┊:* ⃟ ⃟  ━ೋ๑————๑ೋ━* ⃟ ⃟ *      
*║┊:◄✜┢┅ீ͜ৡৢ͜͡✦━━◇━━ீ͜ৡৢ͜͡✦┅┧✜►*
*║┊:*      ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈  
*║┊:*   𝑁𝑎𝑚𝑎𝐵𝑜𝑡 : MELCA BOT
*║┊:* 𝐶𝑟𝑒𝑎𝑡𝑜𝑟 : 𝑀𝑎𝑠𝑙𝑒𝑛𝑡
*║┊:* 𝑊𝐴𝑅𝑁𝐼𝑁𝐺!!  𝐷𝑖𝑙𝑎𝑟𝑎𝑛𝑔 𝐶𝑜𝑝𝑦
*║┊:*      ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ 
*║┊:◄✜┢┅ீ͜ৡৢ͜͡✦━━◇━━ீ͜ৡৢ͜͡✦┅┧✜►*
*║┊:  * ⃟ ⃟  ━ೋ๑————๑ೋ━* ⃟ ⃟ *   
*╰═┅ৡৢ͜͡✦═══╡꧁꧂╞═══┅ৡৢ͜͡✦═╯*

╭▬▬▬▬▬▬▬▬ *˚✯ཻ⸙۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪ࣤ ̥•┉┉•
⊱✦•* 𝑓𝑖𝑡𝑢𝑟 𝐼𝑐ℎ𝑖 𝐵𝑜𝑡
▋╭┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅   
▋┋*${prefix}info
▋┋*${prefix}owner
▋┋*${prefix}donasi
▋┋*${prefix}repot
▋┋*${prefix}speed
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙𝐼𝑐ℎ𝑖 𝑀𝑒𝑑𝑖𝑎
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}sticker
▋┋*${prefix}tsticker
▋┋*${prefix}toimg
▋┋*${prefix}wait
▋┋*${prefix}kbbi
▋┋*${prefix}imoji
▋┋*${prefix}url2img
▋┋*${prefix}playstore
▋┋*${prefix}babi
▋┋*${prefix}anjing
▋┋*${prefix}unta
▋┋*${prefix}elag
▋┋*${prefix}inu
▋┋*${prefix}joox
▋┋*${prefix}randomcat
▋┋*${prefix}wallpaperhd
▋┋*${prefix}ssweb
▋┋*${prefix}memeindo
▋┋*${prefix}ttp
▋┋*${prefix}meme
▋┋*${prefix}tep
▋┋*${prefix}tts
▋┋*${prefix}tes
▋┋*${prefix}pinterest
▋┋*${prefix}image
▋┋*${prefix}igstalk
▋┋*${prefix}fototiktok
▋┋*${prefix}tiktokstalk
▋┋*${prefix}tiktok
▋┋*${prefix}ytmp4
▋┋*${prefix}ytmp3
▋┋*${prefix}ytsearch
▋┋*${prefix}ocr
▋┋*${prefix}nulis
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙𝐼𝑐ℎ𝑖 𝑀𝑎𝑟𝑘𝑒𝑟 <𝑡𝑒𝑥𝑡 | 𝑡𝑒𝑥𝑡>
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}firetext
▋┋*${prefix}snow
▋┋*${prefix}marvelogo
▋┋*${prefix}epep
▋┋*${prefix}text3d
▋┋*${prefix}textscreen
▋┋*${prefix}lionlogo
▋┋*${prefix}water
▋┋*${prefix}rtext
▋┋*${prefix}party
▋┋*${prefix}ninjalogo
▋┋*${prefix}stiltext
▋┋*${prefix}lovemake
▋┋*${prefix}textblue
▋┋*${prefix}textdark
▋┋*${prefix}galaxtext
▋┋*${prefix}quotemarker
▋┋*${prefix}wolflogo
▋┋*${prefix}wolflogo2
▋┋*${prefix}phlogo
▋┋*${prefix}glitch
▋┋*${prefix}tahta
▋┋*${prefix}thunder
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙𝐼𝑐ℎ𝑖 𝐴𝑛𝑖𝑚𝑒 
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}openanime
▋┋*${prefix}naruto
▋┋*${prefix}minato
▋┋*${prefix}boruto
▋┋*${prefix}hinata
▋┋*${prefix}sasuke
▋┋*${prefix}sakura
▋┋*${prefix}kineki
▋┋*${prefix}toukacan
▋┋*${prefix}rize
▋┋*${prefix}akira
▋┋*${prefix}itori
▋┋*${prefix}kurumi
▋┋*${prefix}miku
▋┋*${prefix}anime
▋┋*${prefix}nekoanime
▋┋*${prefix}loli
▋┋*${prefix}loli2
▋┋*${prefix}waifu
▋┋*${prefix}waifu2
▋┋*${prefix}wibu
▋┋*${prefix}randomanime
▋┋*${prefix}pokemon
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙𝐼𝑐ℎ𝑖 𝐹𝑢𝑛
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}artinama
▋┋*${prefix}truth
▋┋*${prefix}dare
▋┋*${prefix}tebakgambar
▋┋*${prefix}family100
▋┋*${prefix}caklontong
▋┋*${prefix}game
▋┋*${prefix}primbonjodoh
▋┋*${prefix}ramaljodoh
▋┋*${prefix}ramaljadian
▋┋*${prefix}mlherolist
▋┋*${prefix}bucin
▋┋*${prefix}persengay
▋┋*${prefix}ramalhp
▋┋*${prefix}cekjodoh
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙MELCA 𝐼𝑛𝑓𝑜
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}infogc
▋┋*${prefix}infogempa
▋┋*${prefix}infocuaca
▋┋*${prefix}infonomor
▋┋*${prefix}infomobil
▋┋*${prefix}infomotor
▋┋*${prefix}groupinfo
▋┋*${prefix}lirik
▋┋*${prefix}quotes
▋┋*${prefix}cerpen
▋┋*${prefix}chord
▋┋*${prefix}wiki
▋┋*${prefix}brainly
▋┋*${prefix}resepmakanan
▋┋*${prefix}map
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙MELCA 𝐹𝑖𝑡𝑢𝑟 𝐺𝑟𝑜𝑢𝑝
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}add
▋┋*${prefix}kick
▋┋*${prefix}promote
▋┋*${prefix}demote
▋┋*${prefix}setname
▋┋*${prefix}setdesc
▋┋*${prefix}welcome
▋┋*${prefix}nsfw
▋┋*${prefix}simih
▋┋*${prefix}group
▋┋*${prefix}tagme
▋┋*${prefix}hidetag
▋┋*${prefix}tag
▋┋*${prefix}tagall
▋┋*${prefix}fitnah
▋┋*${prefix}infogc
▋┋*${prefix}groupinfo
▋┋*${prefix}linkgroup
▋┋*${prefix}listadmins
▋┋*${prefix}openanime
▋┋*${prefix}edotense
▋┋*${prefix}kudeta
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙MELCA 𝑁𝑠𝑓𝑤 𝑀𝑒𝑛𝑢
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}nsfwloli
▋┋*${prefix}nswflowjob
▋┋*${prefix}nsfwneko
▋┋*${prefix}nsfwtrap
▋┋*${prefix}randomhentai
▋┋*${prefix}hentai
▋┋*${prefix}indohot
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙MELCA 𝐾𝑒𝑟𝑎𝑛𝑔
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}apakah
▋┋*${prefix}kapankah
▋┋*${prefix}bisakah
▋┋*${prefix}rate
▋┋*${prefix}watak
▋┋*${prefix}hobi
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙𝑂𝑡ℎ𝑒𝑟𝑠 MELCA
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}blosklist
▋┋*${prefix}say
▋┋*${prefix}hilih
▋┋*${prefix}testime
▋┋*${prefix}delete
▋┋*${prefix}shorturl
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙MELCA 𝑂𝑤𝑛𝑒𝑟 𝐹𝑖𝑡𝑢𝑟
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}bc -promosi*
▋┋*${prefix}ban -banned
▋┋*${prefix}block -blok
▋┋*${prefix}unblok
▋┋*${prefix}clearall
▋┋*${prefix}clone
▋┋*${prefix}getses
▋┋*${prefix}setpp
▋┋*${prefix}leave
═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡
*(•♛•)─•••──ೇุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุ──────﹒ׂׂૢ་༘࿐ೢִֶָ──╮*
*▄▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▄*        
    *┏ೋ┉━┉ೋ✧ೋ┉━┉ೋ┓*
            𝑌𝑇 : FEMASS GAMERZ
    *┗ೋ┉━┉ೋ✧ೋ┉━┉ೋ┛*
*▀▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▀*       
   ۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈ٜٜٜٜٜٜٜ͡҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ©`
}
exports.help = help
